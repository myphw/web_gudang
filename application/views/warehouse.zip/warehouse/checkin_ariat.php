
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title?></h1>

        

        <div class="row">
            <div class="col-lg-12">

            <?= form_error('form','<div class="alert alert-danger" role="alert">', '
                </div>'); ?>

                <?= $this->session->flashdata('message'); ?>
            
                <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newCheckinModal">Add Material Check IN</a>
                <a href="" class="btn btn-success mb-3" data-toggle="modal" data-target="#newCheckinSIZEModal">Add Material Check IN (SIZE run)</a>
                <a href="<?= base_url().'warehouse/index_checkin';?>" class="btn btn-secondary mb-3" ><i class="fas fa-reply"></i> BACK</a>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th >No</th>
                        <th>No Surat</th>
                        <th>Supplier</th>
                        <th>PO Number</th>
                        <th>Nama Material</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Keterangan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach($checkin as $ci) : ?> 
                    <tr>
                        <th><?= $i; ?></th>
                        <td><?= $ci['no_sj']?></td>
                        <td><?= $ci['supplier']?></td>
                        <td><?= $ci['po_number']?></td>
                        <td><?= $ci['nama_material']?></td>
                        <td><?= $ci['qty']?></td>
                        <td><?= $ci['unit']?></td>
                        <td><?= $ci['ket']?></td>

                        <td>
                            <a href="" class="badge badge-success" data-toggle="modal" data-target="#updateBrandModal<?= $ci['id_checkin'] ?>">Edit</a>
                            <a href="<?= base_url('warehouse/delete_checkin_ariat/'.$ci['id_checkin'])?>" name="btn-delete" class="badge badge-danger">delete</a>
                            <a href="" class="badge badge-warning" data-toggle="modal" data-target="#CheckoutMaterialModal<?= $ci['id_transaksi'] ?>">Check OUT</a>
                        </td>
                     
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
 

            </div>
        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Modal Check IN Ariat -->
<div class="modal fade" id="newCheckinModal" tabindex="-1" aria-labelledby="newCheckinModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="newCheckinModalLabel">Add Material Check In</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?= base_url('warehouse/check_in_ariat'); ?>" method="post">
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="id_transaksi">ID Transaksi</label>
                                <input type="text" name="id_transaksi" class="form-control" value="WG-<?= date("Y"); ?><?= random_string('numeric', 8); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="brand">Brand</label>
                                <input type="text" name="brand" class="form-control" value="ARIAT" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="keterangan">Check IN</label>
                                <input type="text" name="keterangan" class="form-control" value="CHECK IN" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="tanggal_masuk">Date Check IN</label>
                        <input type="date" name="tanggal_masuk" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="no_sj">No Surat Jalan</label>
                                <input type="text" name="no_sj" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="supplier">Supplier</label>
                                <input type="text" name="supplier" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="po_number">PO Number</label>
                        <input type="text" name="po_number" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="art">Art</label>
                        <input type="text" name="art" class="form-control">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="jenis_material">Jenis Material</label>
                                <input type="text" name="jenis_material" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="kode_material">Kode Material</label>
                                <input type="text" name="kode_material" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="nama_material">Nama Material</label>
                        <input type="text" name="nama_material" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="qty">Quantity</label>
                                <input type="number" name="qty" class="form-control" required min="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <input type="text" name="unit" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ket">XFD</label>
                        <input type="text" name="ket" class="form-control">
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>

        </div>
    </div>
</div>


<?php foreach($checkin as $ci) : ?>
<div class="modal fade" id="updateBrandModal<?= $ci['id_checkin'] ?>" tabindex="-1" aria-labelledby="updateBrandModalLabel<?= $ci['id_checkin'] ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="updateBrandModalLabel<?= $ci['id_checkin'] ?>">Update Brand</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
            <form action="<?= base_url('form/update_brand/'.$ci['id_checkin'])?>" method="post">
                <div class="modal-body">
                    <input type="hidden" name="id_brand" value="<?= $ci['id_checkin']?>"> 
                    <div class="form-group">
                        <input type="text" class="form-control" id="brand_name<?= $ci['id_checkin'] ?>" name="brand_name" value="<?= $ci['no_sj']?>" placeholder="Brand Name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
 Modal Check IN SIZE RUN
 -------------------------------------------------------------------------------------------------------------
 -------------------------------------------------------------------------------------------------------------
 --------------------------------------------------------------------------------------------------------------->
<!-- Modal: Add Material Check In with SIZE (ARIAT) -->
<!-- New Checkin Modal -->
<div class="modal fade" id="newCheckinSIZEModal" tabindex="-1" aria-labelledby="newCheckinSIZEModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="newCheckinSIZEModalLabel">Add Material Check In (ARIAT)</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form action="<?= base_url('warehouse/check_in_ariat'); ?>" method="post">
        <div class="modal-body">
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="id_transaksi">ID Transaksi</label>
                <input type="text" id="id_transaksi" name="id_transaksi" class="form-control" 
                       value="WG-<?= date('Y') . random_string('numeric', 8); ?>" readonly>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="brand">Brand</label>
                <input type="text" id="brand" name="brand" class="form-control" value="ARIAT" readonly>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="keterangan">Keterangan</label>
                <input type="text" id="keterangan" name="keterangan" class="form-control" value="CHECK IN" readonly>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="tanggal_masuk">Date Check IN</label>
            <input type="date" id="tanggal_masuk" name="tanggal_masuk" class="form-control">
          </div>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="no_sj">No Surat Jalan</label>
                <input type="text" id="no_sj" name="no_sj" class="form-control">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="supplier">Supplier</label>
                <input type="text" id="supplier" name="supplier" class="form-control">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="po_number">PO Number</label>
            <input type="text" id="po_number" name="po_number" class="form-control">
          </div>

          <div class="form-group">
            <label for="art">Art</label>
            <input type="text" id="art" name="art" class="form-control">
          </div>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="jenis_material">Jenis Material</label>
                <input type="text" id="jenis_material" name="jenis_material" class="form-control">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="kode_material">Kode Material</label>
                <input type="text" id="kode_material" name="kode_material" class="form-control">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="nama_material">Nama Material</label>
            <input type="text" id="nama_material" name="nama_material" class="form-control">
          </div>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="qty">Quantity</label>
                <input type="number" id="qty" name="qty" class="form-control">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="unit">Unit</label>
                <input type="text" id="unit" name="unit" class="form-control">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="ket">XFD</label>
            <input type="text" id="ket" name="ket" class="form-control">
          </div>

          <hr>
          <center><strong>-- SIZE RUN --</strong></center><br>

          <?php
            $sizes = ['6D', '6TD', '7D', '7TD', '8D', '8TD', '9D', '9TD', '10D', '10TD', '11D', '11TD', '12D', '13D', '14D', '15D'];
            foreach (array_chunk($sizes, 4) as $rowSizes): ?>
              <div class="row">
                <?php foreach ($rowSizes as $size): 
                  $inputName = 's' . strtolower($size);
                ?>
                  <div class="col-md-3">
                    <div class="form-group">
                      <label for="<?= $inputName ?>">Size <?= $size ?></label>
                      <input type="number" id="<?= $inputName ?>" name="<?= $inputName ?>" class="form-control">
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
          <?php endforeach; ?>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>



<!------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
MODAL UNTUK CHECK OUT 
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------- -->





<script>

  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
    })
  });

</script>