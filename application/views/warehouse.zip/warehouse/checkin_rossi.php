
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-4 text-gray-800"><?= $title?></h1>

        

        <div class="row">
            <div class="col-lg-12">

            <?= form_error('form','<div class="alert alert-danger" role="alert">', '
                </div>'); ?>

                <?= $this->session->flashdata('message'); ?>
            
                <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newCheckinModal">Add Material Check IN</a>
                <a href="" class="btn btn-success mb-3" data-toggle="modal" data-target="#newCheckinSIZEModal">Add Material Check IN (SIZE run)</a>
                <a href="<?= base_url().'warehouse/index_checkin';?>" class="btn btn-secondary mb-3" ><i class="fas fa-reply"></i> BACK</a>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th >No</th>
                        <th>No Surat</th>
                        <th>Supplier</th>
                        <th>PO Number</th>
                        <th>Nama Material</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Keterangan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach($checkin as $ci) : ?> 
                    <tr>
                        <th><?= $i; ?></th>
                        <td><?= $ci['no_sj']?></td>
                        <td><?= $ci['supplier']?></td>
                        <td><?= $ci['po_number']?></td>
                        <td><?= $ci['nama_material']?></td>
                        <td><?= $ci['qty']?></td>
                        <td><?= $ci['unit']?></td>
                        <td><?= $ci['ket']?></td>

                        <td>
                            <a href="" class="badge badge-success" data-toggle="modal" data-target="#updateBrandModal<?= $ci['id_checkin'] ?>">Edit</a>
                            <a href="<?= base_url('warehouse/delete_checkin_rossi/'.$ci['id_checkin'])?>" name="btn-delete" class="badge badge-danger">delete</a>
                            <a href="" class="badge badge-warning" data-toggle="modal" data-target="#CheckoutMaterialModal<?= $ci['id_transaksi'] ?>">Check OUT</a>
                        </td>
                     
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
 

            </div>
        </div>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->


<!-- Modal Check IN Biasa -->
<div class="modal fade" id="newCheckinModal" tabindex="-1" aria-labelledby="newCheckinModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="newCheckinModalLabel">Add Material Check In</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?= base_url('warehouse/check_in_rossi'); ?>" method="post">
                <div class="modal-body">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="id_transaksi">ID Transaksi</label>
                                <input type="text" name="id_transaksi" class="form-control" value="WG-<?= date('Y'); ?><?= random_string('numeric', 8); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="brand">Brand</label>
                                <input type="text" name="brand" class="form-control" value="ROSSI" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="keterangan">Check IN</label>
                                <input type="text" name="keterangan" class="form-control" value="CHECK IN" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="tanggal_masuk">Date Check IN</label>
                        <input type="date" name="tanggal_masuk" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="no_sj">No Surat Jalan</label>
                                <input type="text" name="no_sj" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="supplier">Supplier</label>
                                <input type="text" name="supplier" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="po_number">PO Number</label>
                        <input type="text" name="po_number" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="art">Art</label>
                        <input type="text" name="art" class="form-control">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="jenis_material">Jenis Material</label>
                                <input type="text" name="jenis_material" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="kode_material">Kode Material</label>
                                <input type="text" name="kode_material" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="nama_material">Nama Material</label>
                        <input type="text" name="nama_material" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="qty">Quantity</label>
                                <input type="number" step="any" name="qty" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <input type="text" name="unit" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ket">XFD</label>
                        <input type="text" name="ket" class="form-control">
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>

            </form>
        </div>
    </div>
</div>


<?php foreach($checkin as $ci) : ?>
<div class="modal fade" id="updateBrandModal<?= $ci['id_checkin'] ?>" tabindex="-1" aria-labelledby="updateBrandModalLabel<?= $ci['id_checkin'] ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="updateBrandModalLabel<?= $ci['id_checkin'] ?>">Update Brand</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
            <form action="<?= base_url('form/update_brand/'.$ci['id_checkin'])?>" method="post">
                <div class="modal-body">
                    <input type="hidden" name="id_brand" value="<?= $ci['id_checkin']?>"> 
                    <div class="form-group">
                        <input type="text" class="form-control" id="brand_name<?= $ci['id_checkin'] ?>" name="brand_name" value="<?= $ci['no_sj']?>" placeholder="Brand Name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Modal Check IN SIZE -->
<div class="modal fade" id="newCheckinSIZEModal" tabindex="-1" aria-labelledby="newCheckinSIZEModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="newCheckinSIZEModalLabel">Add Material Check In</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?= base_url('warehouse/check_in_rossi'); ?>" method="post">
                <div class="modal-body">

                    <!-- Basic Info -->
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="id_transaksi">ID Transaksi</label>
                                <input type="text" name="id_transaksi" class="form-control" value="WG-<?= date("Y"); ?><?= random_string('numeric', 8); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="brand">Brand</label>
                                <input type="text" name="brand" class="form-control" value="ROSSI" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="keterangan">Check IN</label>
                                <input type="text" name="keterangan" class="form-control" value="CHECK IN" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="tanggal_masuk">Date Check IN</label>
                        <input type="date" name="tanggal_masuk" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="no_sj">No Surat Jalan</label>
                                <input type="text" name="no_sj" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="supplier">Supplier</label>
                                <input type="text" name="supplier" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="po_number">PO Number</label>
                        <input type="text" name="po_number" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="art">Art</label>
                        <input type="text" name="art" class="form-control">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="jenis_material">Jenis Material</label>
                                <input type="text" name="jenis_material" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="kode_material">Kode Material</label>
                                <input type="text" name="kode_material" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="nama_material">Nama Material</label>
                        <input type="text" name="nama_material" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="qty">Quantity</label>
                                <input type="number" name="qty" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="unit">Unit</label>
                                <input type="text" name="unit" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ket">XFD</label>
                        <input type="text" name="ket" class="form-control">
                    </div>

                    <!-- Size Run -->
                    <hr>
                    <center><p><strong>-- SIZE RUN --</strong></p></center>
                    <div class="row">
                        <?php
                        $sizes = [
                            's3' => 'Size 3', 's3t' => 'Size 3T',
                            's4' => 'Size 4', 's4t' => 'Size 4T',
                            's5' => 'Size 5', 's5t' => 'Size 5T',
                            's6' => 'Size 6', 's6t' => 'Size 6T',
                            's7' => 'Size 7', 's7t' => 'Size 7T',
                            's8' => 'Size 8', 's8t' => 'Size 8T',
                            's9' => 'Size 9', 's9t' => 'Size 9T',
                            's10' => 'Size 10', 's10t' => 'Size 10T',
                            's11' => 'Size 11', 's11t' => 'Size 11T',
                            's12' => 'Size 12', 's13' => 'Size 13',
                            's14' => 'Size 14', 's15' => 'Size 15'
                        ];
                        foreach ($sizes as $name => $label): ?>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="<?= $name ?>"><?= $label ?></label>
                                    <input type="number" name="<?= $name ?>" class="form-control" min="0">
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>

        </div>
    </div>
</div>


<?php foreach($checkin as $ci) : ?>
<div class="modal fade" id="updateBrandModal<?= $ci['id_checkin'] ?>" tabindex="-1" aria-labelledby="updateBrandModalLabel<?= $ci['id_checkin'] ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="updateBrandModalLabel<?= $ci['id_checkin'] ?>">Update Brand</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
            <form action="<?= base_url('form/update_brand/'.$ci['id_checkin'])?>" method="post">
                <div class="modal-body">
                    <input type="hidden" name="id_brand" value="<?= $ci['id_checkin']?>"> 
                    <div class="form-group">
                        <input type="text" class="form-control" id="brand_name<?= $ci['id_checkin'] ?>" name="brand_name" value="<?= $ci['no_sj']?>" placeholder="Brand Name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php foreach($checkin as $ci): ?>
<div class="modal fade" id="CheckoutMaterialModal<?= $ci['id_transaksi'] ?>" tabindex="-1" aria-labelledby="CheckoutMaterialModalLabel<?= $ci['id_transaksi'] ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="CheckoutMaterialModalLabel<?= $ci['id_transaksi'] ?>">Check OUT Material</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?= base_url('warehouse/update_checkout_rossi/' . $ci['id_transaksi']) ?>" method="post">
            <div class="modal-body">
                <input type="hidden" name="id_transaksi" value="<?= $ci['id_transaksi'] ?>">

                <div class="row">
                    <div class="col-md-4">
                        <label>ID Transaksi</label>
                        <input type="text" class="form-control" value="<?= $ci['id_transaksi'] ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>Check OUT</label>
                        <input type="text" name="keterangan" class="form-control" value="CHECK OUT" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>No Surat Jalan</label>
                        <input type="text" name="no_sj" class="form-control" value="<?= $ci['no_sj'] ?>" readonly>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col-md-6">
                        <label>Brand</label>
                        <input type="text" name="brand" class="form-control" value="ROSSI" readonly>
                    </div>
                    <div class="col-md-6">
                        <label>Supplier</label>
                        <input type="text" name="supplier" class="form-control" value="<?= $ci['supplier'] ?>" readonly>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col-md-4">
                        <label>Date Check IN</label>
                        <input type="text" name="tanggal_masuk" class="form-control" value="<?= $ci['tanggal_masuk'] ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>Date Check OUT</label>
                        <input type="date" name="tanggal_keluar" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label>TO Department</label>
                        <select name="dept_tujuan" class="form-control" required>
                            <option value="">-- Send TO --</option>
                            <?php foreach (['CUTTING','SEWING','SEMI WH','LASTING','FINISHING','PACKING'] as $dept): ?>
                                <option value="<?= $dept ?>"><?= $dept ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row mt-2">
                    <div class="col-md-4">
                        <label>PO Number</label>
                        <input type="text" name="po_number" class="form-control" value="<?= $ci['po_number'] ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>Art</label>
                        <input type="text" name="art" class="form-control" value="<?= $ci['art'] ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label>Jenis Material</label>
                        <input type="text" name="jenis_material" class="form-control" value="<?= $ci['jenis_material'] ?>" readonly>
                    </div>
                </div>

                <div class="form-group mt-2">
                    <label>Kode Material</label>
                    <input type="text" name="kode_material" class="form-control" value="<?= $ci['kode_material'] ?>" readonly>
                </div>
                <div class="form-group">
                    <label>Nama Material</label>
                    <input type="text" name="nama_material" class="form-control" value="<?= $ci['nama_material'] ?>" readonly>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <label>Quantity</label>
                        <input type="number" name="qty" class="form-control" value="<?= $ci['qty'] ?>">
                    </div>
                    <div class="col-md-6">
                        <label>Unit</label>
                        <input type="text" name="unit" class="form-control" value="<?= $ci['unit'] ?>" readonly>
                    </div>
                </div>

                <div class="form-group mt-2">
                    <label>Keterangan</label>
                    <input type="text" name="ket" class="form-control" value="<?= $ci['ket'] ?>" readonly>
                </div>

                <hr>
                <center><strong>-- SIZE RUN --</strong></center>

                <?php
                $sizes = ['s3','s3t','s4','s4t','s5','s5t','s6','s6t','s7','s7t','s8','s8t','s9','s9t','s10','s10t','s11','s11t','s12','s13','s14','s15'];
                foreach (array_chunk($sizes, 4) as $chunk): ?>
                    <div class="row mt-2">
                        <?php foreach ($chunk as $size): ?>
                            <div class="col-md-3">
                                <label for="<?= $size ?>">Size <?= strtoupper($size) ?></label>
                                <input type="number" name="<?= $size ?>" class="form-control" value="<?= $ci[$size] ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-warning"><b>! CHECK OUT !</b></button>
            </div>
        </form>
        </div>
    </div>
</div>
<?php endforeach; ?>


<script>

  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
    })
  });

</script>